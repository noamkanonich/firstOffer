package com.firstoffer.firstoffer;

import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import io.vertx.core.Vertx;
import io.vertx.core.VertxOptions;
import io.vertx.core.dns.AddressResolverOptions;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.unit.Async;
import io.vertx.ext.unit.TestOptions;
import io.vertx.ext.unit.TestSuite;
import io.vertx.ext.unit.report.ReportOptions;
import io.vertx.ext.web.client.HttpResponse;
import io.vertx.ext.web.client.WebClient;
import io.vertx.ext.web.client.WebClientOptions;
import io.vertx.ext.web.codec.BodyCodec;
// import io.vertx.junit5.Checkpoint;
import io.vertx.junit5.VertxExtension;
import io.vertx.junit5.VertxTestContext;

@ExtendWith(VertxExtension.class)
public class TestMainVerticle {

  @BeforeEach
  void deploy_verticle(Vertx vertx, VertxTestContext testContext) {
    vertx.deployVerticle(new MainVerticle(), testContext.succeeding(id -> testContext.completeNow()));
  }

  @Test
  void verticle_deployed(Vertx vertx, VertxTestContext testContext) throws Throwable {
    testContext.completeNow();
  }

  // @Test
  // @DisplayName("🚀 Deploy a HTTP service verticle")
  // void useMainVerticle(Vertx vertx, VertxTestContext testContext) throws InterruptedException {
  //   WebClient webClient = WebClient.create(vertx);
  //   vertx.deployVerticle(new MainVerticle(), handler -> {
  //     if (handler.succeeded()) {
  //       webClient.get(8080, "localhost", "/").as(BodyCodec.string()).send(response -> {
  //         testContext.completeNow();
  //       });
  //     }
  //   });
  // }

  public static void main(String[] args) {

    final Vertx vertx = Vertx.vertx(new VertxOptions().setAddressResolverOptions(new AddressResolverOptions()
        .addServer("192.168.0.1").addServer("192.168.0.2:40000").addServer("https://localhost:8080")));

    JsonArray locationsArray = new JsonArray();
    JsonObject washington = new JsonObject();
    JsonObject london = new JsonObject();
    JsonObject jerusalem = new JsonObject();

    washington.put("City", "Washington");
    washington.put("Country", "US");
    locationsArray.add(washington);
    london.put("City", "London");
    london.put("Country", "GB");
    locationsArray.add(london);
    jerusalem.put("City", "Jerusalem");
    jerusalem.put("Country", "IL");
    locationsArray.add(jerusalem);

    TestSuite suite = TestSuite.create("First Offer Test Suit");

    suite.test("Test case 1 - /healthcheck", context -> {
      Async async = context.async();

      vertx.deployVerticle(new MainVerticle(), handler -> {
        if (handler.succeeded()) {
          System.out.println("Verticle deployed with deployment id: " + handler.result());
          WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(8080));
          client.get("/healthcheck").as(BodyCodec.string()).send(routingContext -> {
            if (routingContext.succeeded()) {
              HttpResponse<String> response = routingContext.result();
              System.out.println(response.body());
              async.complete();
            } else {
              context.fail(routingContext.cause());
              // throw new RuntimeException("it failed!");
            }
          });

        } else {
          handler.cause().printStackTrace();
        }

      });
    }).test("Test case 2 - /hello with name as param", context -> {
      Async async = context.async();

      vertx.deployVerticle(new MainVerticle(), handler -> {
        if (handler.succeeded()) {
          WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(8080));
          client.get("/hello").addQueryParam("name", "First Offer").as(BodyCodec.string()).send(routingContext -> {
            if (routingContext.succeeded()) {
              HttpResponse<String> response = routingContext.result();
              System.out.println(response.body());
              async.complete();
            } else {
              context.fail(routingContext.cause());
            }
          });
        } else {
          handler.cause().printStackTrace();
        }
      });
    }).test("Test case 3 - /currentforecasts with city (Washington) and country (US) as params", context -> {
      Async async = context.async();

      vertx.deployVerticle(new MainVerticle(), handler -> {
        if (handler.succeeded()) {
          WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(8080));
          client.get("/currentforecasts").addQueryParam("city", locationsArray.getJsonObject(0).getString("City"))
              .addQueryParam("country", locationsArray.getJsonObject(0).getString("Country")).as(BodyCodec.jsonObject())
              .send(routingContext -> {
                if (routingContext.succeeded()) {
                  HttpResponse<JsonObject> response = routingContext.result();
                  // assertThat(response.body()).contains("temp");
                  System.out.println(response.body());
                  async.complete();
                } else {
                  context.fail(routingContext.cause());
                }
              });

        } else {
          handler.cause().printStackTrace();
        }
      });
    }).test("Test case 4 - /currentforecasts with city (London) and country (GB) as params", context -> {
      Async async = context.async();

      vertx.deployVerticle(new MainVerticle(), handler -> {
        if (handler.succeeded()) {
          WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(8080));
          client.get("/currentforecasts").addQueryParam("city", locationsArray.getJsonObject(1).getString("City"))
              .addQueryParam("country", locationsArray.getJsonObject(1).getString("Country")).as(BodyCodec.jsonObject())
              .send(routingContext -> {
                if (routingContext.succeeded()) {
                  HttpResponse<JsonObject> response = routingContext.result();
                  System.out.println(response.body());
                  async.complete();
                } else {
                  context.fail(routingContext.cause());
                }
              });

        } else {
          handler.cause().printStackTrace();
        }
      });
    }).test("Test case 5 - /currentforecasts with city (Jerusalem) and country (IL) as params", context -> {
      Async async = context.async();

      vertx.deployVerticle(new MainVerticle(), handler -> {
        if (handler.succeeded()) {
          WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(8080));
          client.get("/currentforecasts").addQueryParam("city", locationsArray.getJsonObject(2).getString("City"))
              .addQueryParam("country", locationsArray.getJsonObject(2).getString("Country")).as(BodyCodec.jsonObject())
              .send(routingContext -> {
                if (routingContext.succeeded()) {
                  HttpResponse<JsonObject> response = routingContext.result();
                  System.out.println(response.body());
                  async.complete();
                } else {
                  context.fail(routingContext.cause());
                }
              });
        } else {
          handler.cause().printStackTrace();
        }
      });
    }).test("Test case 6 - /forecasts with city (Washington), country (US) and days (2) as params", context -> {
      Async async = context.async();

      vertx.deployVerticle(new MainVerticle(), handler -> {
        if (handler.succeeded()) {
          WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(8080));
          client.get("/forecasts").addQueryParam("city", locationsArray.getJsonObject(0).getString("City"))
              .addQueryParam("country", locationsArray.getJsonObject(0).getString("Country")).addQueryParam("days", "2")
              .as(BodyCodec.jsonObject()).send(routingContext -> {
                if (routingContext.succeeded()) {
                  HttpResponse<JsonObject> response = routingContext.result();
                  System.out.println(response.body());
                  async.complete();
                } else {
                  context.fail(routingContext.cause());
                }
              });

        } else {
          handler.cause().printStackTrace();
        }
      });
    }).test("Test case 7 - /forecasts with city (London), country (GB) and days (3) as params", context -> {
      Async async = context.async();

      vertx.deployVerticle(new MainVerticle(), handler -> {
        if (handler.succeeded()) {
          WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(8080));
          client.get("/forecasts").addQueryParam("city", locationsArray.getJsonObject(1).getString("City"))
              .addQueryParam("country", locationsArray.getJsonObject(1).getString("Country")).addQueryParam("days", "3")
              .as(BodyCodec.jsonObject()).send(routingContext -> {
                if (routingContext.succeeded()) {
                  HttpResponse<JsonObject> response = routingContext.result();
                  System.out.println(response.body());
                  async.complete();
                } else {
                  context.fail(routingContext.cause());
                }
              });
        } else {
          handler.cause().printStackTrace();
        }
      });
    }).test("Test case 8 - /forecasts with city (Jerusalem), country (IL) and days (4) as params", context -> {
      Async async = context.async();

      vertx.deployVerticle(new MainVerticle(), handler -> {
        if (handler.succeeded()) {
          WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(8080));
          client.get("/forecasts").addQueryParam("city", locationsArray.getJsonObject(2).getString("City"))
              .addQueryParam("country", locationsArray.getJsonObject(2).getString("Country")).addQueryParam("days", "4")
              .as(BodyCodec.jsonObject()).send(routingContext -> {
                if (routingContext.succeeded()) {
                  HttpResponse<JsonObject> response = routingContext.result();
                  System.out.println(response.body());
                  async.complete();
                } else {
                  context.fail(routingContext.cause());
                }
              });

        } else {
          handler.cause().printStackTrace();
        }
      });
    }).test("Test case 9 - /forecasts with city as '' for failing the test on purpse", context -> {
      Async async = context.async();

      vertx.deployVerticle(new MainVerticle(), handler -> {
        if (handler.succeeded()) {
          WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(8080));
          client.get("/forecasts").addQueryParam("city", "")
              .addQueryParam("country", locationsArray.getJsonObject(0).getString("Country")).addQueryParam("days", "2")
              .as(BodyCodec.jsonObject()).send(routingContext -> {
                if (routingContext.succeeded()) {
                  HttpResponse<JsonObject> response = routingContext.result();
                  System.out.println(response.body());
                } else {
                  // context.fail(routingContext.cause());
                  context.fail();
                  // throw new RuntimeException("it failed!");
                }
                async.complete();
              });
        } else {
          handler.cause().printStackTrace();
        }
      });
    }).test("Test case 10 - /currentforecasts with city as 'none' for failing the test on purpse", context -> {
      Async async = context.async();

      vertx.deployVerticle(new MainVerticle(), handler -> {
        if (handler.succeeded()) {
          WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(8080));
          client.get("/currentforecasts").addQueryParam("city", "")
              .addQueryParam("country", locationsArray.getJsonObject(0).getString("Country")).as(BodyCodec.jsonObject())
              .send(routingContext -> {
                if (routingContext.succeeded()) {
                  HttpResponse<JsonObject> response = routingContext.result();
                  System.out.println(response.body());
                } else {
                  // context.fail(routingContext.cause());
                  context.fail();
                }
                async.complete();
              });
        } else {
          handler.cause().printStackTrace();
        }
      });
    }).test("Test case 11 - /currentforecasts with country as 'none' for failing the test on purpse", context -> {
      Async async = context.async();

      vertx.deployVerticle(new MainVerticle(), handler -> {
        if (handler.succeeded()) {
          WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(8080));
          client.get("/currentforecasts").addQueryParam("city", locationsArray.getJsonObject(0).getString("City"))
              .addQueryParam("country", "").as(BodyCodec.jsonObject()).send(routingContext -> {
                try {
                  if (routingContext.succeeded()) {
                    HttpResponse<JsonObject> response = routingContext.result();
                    System.out.println(response.body());
                    async.complete();
                  } else {
                    // throw new AssertionError();
                    context.fail();
                  }
                } catch (AssertionError e) {
                  e.printStackTrace();
                }
              });
        } else {
          handler.cause().printStackTrace();
        }
      });
    }).test("Test case 12 - Wrong endpoint", context -> {
          Async async = context.async();
          vertx.deployVerticle(new MainVerticle(), handler -> {
            if (handler.succeeded()) {
              WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(8080));
              client.get("/current").addQueryParam("city", locationsArray.getJsonObject(2).getString("City"))
                  .addQueryParam("country", locationsArray.getJsonObject(2).getString("Country"))
                  .as(BodyCodec.jsonObject()).send(routingContext -> {
                    if (routingContext.succeeded()) {
                      HttpResponse<JsonObject> response = routingContext.result();
                      System.out.println(response.body());
                      async.complete();
                    } else {
                      // throw new AssertionError();
                      context.fail();
                    }
                  });
              // catch (AssertionError e) {
              // e.printStackTrace();
              // }
            } else {
              handler.cause().printStackTrace();
            }
          });
        }).test("Test case 13 - /forecasts with more than 5 days (10) as param as for failing the test on purpse",
        context -> {
          Async async = context.async();
          vertx.deployVerticle(new MainVerticle(), handler -> {
            if (handler.succeeded()) {
              WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(8080));
              client.get("/forecasts").addQueryParam("city", locationsArray.getJsonObject(0).getString("City"))
                  .addQueryParam("country", locationsArray.getJsonObject(0).getString("Country"))
                  .addQueryParam("days", "10").as(BodyCodec.jsonObject()).send(routingContext -> {
                    if (routingContext.succeeded()) {
                      HttpResponse<JsonObject> response = routingContext.result(); 
                      System.out.println(response.body());     
                      async.complete();                
                    } else {
                      // throw new AssertionError();
                      context.fail();
                    }
                  });
            } else {
              handler.cause().printStackTrace();
            }
          });
        });
    suite.run(new TestOptions().addReporter(new ReportOptions().setTo("console")));
  }
}
