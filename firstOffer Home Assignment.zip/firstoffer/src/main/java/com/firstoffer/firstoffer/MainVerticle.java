package com.firstoffer.firstoffer;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.MultiMap;
// import io.vertx.core.Promise;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// import io.vertx.ext.web.Route;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.client.WebClient;
import io.vertx.ext.web.client.WebClientOptions;
import io.vertx.ext.web.codec.BodyCodec;
import io.vertx.ext.web.client.HttpResponse;

public class MainVerticle extends AbstractVerticle {

  public String api_key = "57dba69c9870d19db3cc362cebb60c0e";
  public String url = "api.openweathermap.org";

  // This function transform the quary params to valid ones (e.g. trim spaces,
  // capitalized first letter)
  public String getValidCityString(String city) {
    String c = "";
    if(city.length() == 0) {
      return "";
    }
    if (city.contains(" ")) {
      c = city.substring(0, 1).toUpperCase() + city.substring(1, city.indexOf(" ")).toLowerCase();
      for (int i = 0; i < city.length(); i++) {
        if (city.charAt(i) == ' ') {
          city = city.substring(i + 1);
          if (city.contains(" ")) {
            c = c + ' ' + city.substring(0, 1).toUpperCase() + city.substring(1, city.indexOf(" ")).toLowerCase();
          } else {
            c = c + ' ' + city.substring(0, 1).toUpperCase() + city.substring(1).toLowerCase();
          }
        }
      }
    } else {
      c = city.substring(0, 1).toUpperCase() + city.substring(1).toLowerCase();
    }
    if (c.contains(" ")) {
      c = c.substring(0, c.indexOf(" "));
    }
    return c;
  }

  @Override
  public void start() throws Exception {
    // Create a Router
    Router router = Router.router(vertx);

    router.get("/healthcheck").handler(routingContext -> {
      routingContext.request().response().end("I'm Alive!!!");
    });

    router.get("/hello").handler(routingContext -> {
      MultiMap queryParams = routingContext.queryParams();
      String name = queryParams.contains("name") ? queryParams.get("name") : "unknown";
      routingContext.request().response().end("Hello " + name + "!");
    });

    router.get("/currentforecasts").handler(routingContext -> {
      // public String api_key = "57dba69c9870d19db3cc362cebb60c0e";
      // public String url = "api.openweathermap.org";
      MultiMap queryParams = routingContext.queryParams();
      String city = queryParams.contains("city") ? queryParams.get("city").trim() : "unknown";
      city = getValidCityString(city);

      String country = queryParams.contains("country") ? queryParams.get("country").substring(0).toUpperCase().trim()
          : "unknown";
      String cityID = "";
      JSONParser jsonFile = new JSONParser();
      try (FileReader reader = new FileReader("./src/cities/city.list.json")) {
        Object obj = jsonFile.parse(reader);
        JSONArray citiesList = (JSONArray) obj;

        for (int i = 0; i < citiesList.size(); i++) {
          JSONObject cityObj = (JSONObject) citiesList.get(i);
          if (cityObj.get("name").equals(city) && cityObj.get("country").equals(country)) {
            cityID = "" + cityObj.get("id");
          }
        }
      } catch (FileNotFoundException e) {
        e.printStackTrace();
      } catch (IOException e) {
        e.printStackTrace();
      } catch (ParseException e) {
        e.printStackTrace();
      }

      WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(80).setDefaultHost(url));
      client.get("/data/2.5/weather?id=" + cityID + "&appid=" + api_key + "&units=metric").as(BodyCodec.jsonObject())
          .send(ar -> {
            if (ar.succeeded()) {
              HttpResponse<JsonObject> response = ar.result();
              System.out.println("Got HTTP response body");
              JsonObject weatherData = new JsonObject();
              if (response.statusCode() == 200) {
                weatherData.put("country", response.body().getJsonObject("sys").getString("country"));
                weatherData.put("city", response.body().getString("name"));
                weatherData.put("temp", response.body().getJsonObject("main").getString("temp"));
                weatherData.put("humidity", response.body().getJsonObject("main").getString("humidity"));
                long l = Long.parseLong(response.body().getString("dt"));
                String date = new java.text.SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date(l * 1000));
                weatherData.put("date", date);
                routingContext.json(weatherData);
              } else {
                System.out
                    .println("Something went wrong, status code: " + response.statusCode() + ". Please try again!");
                routingContext.request().response()
                    .end("Something went wrong, status code: " + response.statusCode() + ". Please try again!");
              }
            } else {
              System.out.println("Something went wrong " + ar.cause().getMessage());
              // ar.cause().printStackTrace();
            }
          });
    });

    router.get("/forecasts").handler(routingContext -> {
      MultiMap queryParams = routingContext.queryParams();
      String city = queryParams.contains("city") ? queryParams.get("city").trim() : "unknown";
      city = getValidCityString(city);
      String country = queryParams.contains("country") ? queryParams.get("country").substring(0).toUpperCase().trim()
          : "unknown";
      String days = queryParams.contains("days") ? queryParams.get("days") : "unknown";
      Integer forecastDays = Integer.parseInt(days);
      if (forecastDays < 0  || forecastDays > 5 || forecastDays == null) {
        // routingContext.fail(400);
        routingContext.request().response().end("Please choose no more than 5 days!");
        return;
      }
      String lat = "";
      String lon = "";

      JSONParser jsonFile = new JSONParser();

      try (FileReader reader = new FileReader("./src/cities/city.list.json")) {
        Object obj = jsonFile.parse(reader);
        JSONArray citiesList = (JSONArray) obj;

        for (int i = 0; i < citiesList.size(); i++) {
          JSONObject cityObj = (JSONObject) citiesList.get(i);
          if (cityObj.get("name").equals(city) && cityObj.get("country").equals(country)) {
            JSONObject coord = (JSONObject) cityObj.get("coord");
            lat = "" + coord.get("lat");
            lon = "" + coord.get("lon");
          }
        }
      } catch (FileNotFoundException e) {
        e.printStackTrace();
      } catch (IOException e) {
        e.printStackTrace();
      } catch (ParseException e) {
        e.printStackTrace();
      }

      // WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(80).setSsl(true).setVerifyHost(false).setDefaultHost(url));
      WebClient client = WebClient.create(vertx, new WebClientOptions().setDefaultPort(80).setDefaultHost(url));
      client.get("/data/2.5/onecall?lat=" + lat + "&lon=" + lon + "&exclude=minutely,hourly&appid=" + api_key
          + "&units=metric").as(BodyCodec.jsonObject()).send(ar -> {
            if (ar.succeeded()) {
              HttpResponse<JsonObject> response = ar.result();
              System.out.println("Got HTTP response body");
              JsonObject forecastData = new JsonObject();
              JsonArray listResponseArray = new JsonArray();
              if (response.statusCode() == 200) {
                listResponseArray = response.body().getJsonArray("daily");
                forecastData.put("forecasts", new JSONArray());
                for (int i = 0; i < forecastDays; i++) {
                  JsonObject dailyForecast = new JsonObject();
                  long l = Long.parseLong(listResponseArray.getJsonObject(i).getString("dt"));
                  String date = new java.text.SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date(l * 1000));
                  dailyForecast.put("date", date);
                  dailyForecast.put("dayTemp",
                      listResponseArray.getJsonObject(i).getJsonObject("temp").getString("day"));
                  dailyForecast.put("minTemp",
                      listResponseArray.getJsonObject(i).getJsonObject("temp").getString("min"));
                  dailyForecast.put("maxTemp",
                      listResponseArray.getJsonObject(i).getJsonObject("temp").getString("max"));
                  forecastData.getJsonArray("forecasts").add(dailyForecast);
                }
                routingContext.json(forecastData);
              } else {
                System.out
                    .println("Something went wrong, status code: " + response.statusCode() + ". Please try again!");
                routingContext.request().response()
                    .end("Something went wrong, status code: " + response.statusCode() + ". Please try again!");
              }
            } else {
              System.out.println("Something went wrong " + ar.cause().getMessage());
              // ar.cause().printStackTrace();
            }
          });
    });

    // Mount the handler for all incoming requests at every path and HTTP method
    router.route("/").handler(context -> {
      // Get the address of the request
      String address = context.request().connection().remoteAddress().toString();
      // Get the query parameter "name"
      MultiMap queryParams = context.queryParams();
      String name = queryParams.contains("name") ? queryParams.get("name") : "unknown";
      // Write a json response
      context.json(new JsonObject().put("name", name).put("address", address).put("message",
          "Hello " + name + " connected from " + address));
    });

    // Create the HTTP server
    vertx.createHttpServer()
        // Handle every request using the router
        .requestHandler(router)
        // Start listening
        .listen(8080)
        // Print the port
        .onSuccess(server -> System.out.println("HTTP server started on port " + server.actualPort()));
  }
}
