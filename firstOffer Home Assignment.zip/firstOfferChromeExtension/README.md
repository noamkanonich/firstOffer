# FirstOffer Weather App Chrome Extension 

For using FirstOffer weather extension, you should do the following steps:
1.	Go to chrome://extensions/
2.	Click on Load unpacked
3.	Choose the file “firstOfferChtomeExtension”
4.	Turn on the extension
5.	Open a new tab
6.	Enter a location
•	Important note – you need to run the above vert.x server before using the chrome extension
