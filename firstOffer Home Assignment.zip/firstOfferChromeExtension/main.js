const form = document.getElementById("form-data");
const results = document.querySelector(".results");
const url = "http://localhost:8080";

if (localStorage.getItem("city") !== null && localStorage.getItem("country") !== null) {
  displayDailyWeather(
    localStorage.getItem("city"),
    localStorage.getItem("country")
  );
}

async function displayDailyWeather(cityQuery, countryQuery) {
  const currentWeatherDiv = document.querySelector(".currentWeather");
  currentWeatherDiv.classList.add("hide");
  const weatherDiv = document.getElementById("weather");
  const location = document.querySelector(".location");
  location.innerHTML = '<h2 class="m-4">' 
  + cityQuery.trim().charAt(0).toUpperCase() 
  + cityQuery.trim().slice(1).toLowerCase() 
  + ", " + countryQuery.trim().toUpperCase() + '</h2>'
  try {
    const response = await axios.get(
      url +
        "/forecasts/?city=" +
        cityQuery +
        "&country=" +
        countryQuery +
        "&days=5"
    );
    response.data["forecasts"].forEach((weatherDay) => {
      let div = document.createElement("div");
      let iconUrl = getWeatherIcon(weatherDay.dayTemp);
      div.classList.add("col");
      div.innerHTML =
        '<article class="box weather">' +
        '<div class="icon bubble black">' +
        '<div class="spin">' +
        '<img src="' +
        iconUrl +
        '">' +
        "</div>" +
        "</div>" +
        '<h3 class="mt-4">' +
        weatherDay.date +
        "</h3>" +
        '<span class="temp">' +
        weatherDay.dayTemp +
        "°</span>" +
        '<span class="high-low">' +
        weatherDay.minTemp +
        "° / " +
        weatherDay.maxTemp +
        "°</span>" +
        "</article>";

      weatherDiv.appendChild(div);
    });
  } catch (error) {
    results.textContent = "Error, try again!";
    console.log("error");
  }
}

async function getCurrentWeather() {
  const dailyWeatherDiv = document.querySelector(".dailyWeather");
  const currentWeatherDiv = document.querySelector(".currentWeather");
  const location = document.querySelector(".currentWeather .location");
  dailyWeatherDiv.classList.add("hide");
  currentWeatherDiv.classList.remove("hide");
  const cityQuery = await document.getElementById("city").value;
  const countryQuery = await document.getElementById("country").value;
  location.innerHTML = '<h2 class="m-4">' 
  + cityQuery.trim().charAt(0).toUpperCase() 
  + cityQuery.trim().slice(1).toLowerCase() 
  + ", " + countryQuery.trim().toUpperCase() + '</h2>'
  try {
    localStorage.setItem("city", cityQuery);
    localStorage.setItem("country", countryQuery);    

    const response = await axios.get(
      url + "/currentforecasts/?city=" + cityQuery + "&country=" + countryQuery
    );
    let iconUrl = getWeatherIcon(response.data.temp);
    let div = document.createElement("div");
    div.innerHTML =
      '<article class="box weather">' +
      '<div class="icon bubble black">' +
      '<div class="spin">' +
      '<img src="' +
      iconUrl +
      '">' +
      "</div>" +
      "</div>" +
      '<h3 class="mt-4 text-center">' +
      response.data.date +
      "</h3>" +
      '<span class="temp">' +
      response.data.temp +
      "°</span>" +
      '<span class="humidity">' +
      response.data.humidity +
      "%</span>" +
      "</article>";

      currentWeatherDiv.removeChild(currentWeatherDiv.lastChild);
      currentWeatherDiv.appendChild(div);
  } catch (error) {
    results.textContent = "Error, try again!";
    console.log("error");
  }
}

function getWeatherIcon(temp) {
    if (temp > 20) {
        return "https://cdn-icons-png.flaticon.com/512/869/869869.png";
      } else if (temp < 20 && temp > 10) {
        return "https://cdn-icons-png.flaticon.com/512/1163/1163661.png";
      } else if (temp < 10) {
        return "https://cdn-icons-png.flaticon.com/512/1163/1163657.png";
      }
}

// declare a function to handle form submission
const handleSubmit = async (e) => {
  localStorage.clear();
  e.preventDefault();
  getCurrentWeather();
};
form.addEventListener("submit", (e) => handleSubmit(e));


